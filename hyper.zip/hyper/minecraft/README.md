<div align="center">
  <a href="https://discord.gg/xCCpfth">
    <img src="https://user-images.githubusercontent.com/59381835/92191514-d649ad80-ee18-11ea-9bc4-e95c7a122a99.png" alt="Discord" width="80"/>
  <a href = "https://www.youtube.com/watch?v=9h5W4-hzts4&t=794s&ab_channel=reconlx">
    <img src="https://user-images.githubusercontent.com/59381835/92191346-676c5480-ee18-11ea-8240-e416eb1a5b5d.png" alt="Discord" width="80"/>
  </a>
</div>

### If you are you need support on the codes feel free to join the support server!
+ Help Command (Youtube Video) : https://www.youtube.com/watch?v=9h5W4-hzts4&t=794s&ab_channel=reconlx


# Command Handler
Why not make your code cleaner and easier to acess when you can, follow these easy steps to use a command handler.

# Steps
1. Download the code from the github repo
2. Edit config.json file with your bot's token
3. When you have it in the code editor run command "npm i ascii-table" in the terminal.
4. Start up the bot with "node ." in the terminal
It should look something like this
![node .](https://i.imgur.com/ThSJRmH.png)

# Contacts
-recon#0001 on discord

